
copy ../output/gts2mini/main.exe to py_amazfit_tools-GTS2mini folder
